"""
@Authors: SOU Deva, CARLIER Axel
"""

import toolbox_model_creation as toolbox

toolbox.create_input_as_csv()
